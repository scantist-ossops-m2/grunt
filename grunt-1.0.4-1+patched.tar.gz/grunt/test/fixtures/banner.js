
/* THIS
 * IS
 * A
 * SAMPLE
 * BANNER!
 */

// Comment

/* Comment */
